﻿//A8977
//Lab 6
//CIS 199 - 01
//October 28 @ 11:59 pm
//Program for discovering grade based on words per minute typed
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_6
{
	public partial class typeForm : Form
	{
		public typeForm()
		{
			InitializeComponent();
		}

		private void typeBtn_Click(object sender, EventArgs e)
		{
			int wordsTyped = 0;// user input
			char grade = 'E';//Grade given with placeholder in case of error
			int[] words = {0,16,31,51,76};//array for the range of words per minute typed in order to pair them with a grade
			char[] grades = { 'F', 'D', 'C', 'B', 'A' };//The possible grades arraged in an array
			bool found = false;// boolean changes to true for correct array match

			if (int.TryParse(wordType.Text, out wordsTyped) && wordsTyped >= 0)// TryParse for ensuring correct input
			{
				int index = words.Length - 1;//index variable for array search
				while(index>=0 && ! found)//while statement for initializing search
				{
					if (wordsTyped >= words[index])//if statement for determining the range
						found = true;// if range found change boolean to true;
					else
						--index;//if input not in first range subtract index until it is found
				}
				if (found)//Runs once boolean found changes to true
					grade = grades[index];//Matching the grade to the range of words
				MessageBox.Show($"Your grade is {grade}");//MessageBox displaying student's grade
			}
			else
			{
				MessageBox.Show("Your input is invalid");//Appears if the input fails the TryParse
			}
		}
	}
}
