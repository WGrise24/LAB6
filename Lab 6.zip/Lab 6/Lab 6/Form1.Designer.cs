﻿namespace Lab_6
{
	partial class typeForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.typeBtn = new System.Windows.Forms.Button();
			this.typeLabel = new System.Windows.Forms.Label();
			this.wordType = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// typeBtn
			// 
			this.typeBtn.Location = new System.Drawing.Point(70, 67);
			this.typeBtn.Name = "typeBtn";
			this.typeBtn.Size = new System.Drawing.Size(75, 23);
			this.typeBtn.TabIndex = 1;
			this.typeBtn.Text = "Enter";
			this.typeBtn.UseVisualStyleBackColor = true;
			this.typeBtn.Click += new System.EventHandler(this.typeBtn_Click);
			// 
			// typeLabel
			// 
			this.typeLabel.AutoSize = true;
			this.typeLabel.Location = new System.Drawing.Point(-2, 44);
			this.typeLabel.Name = "typeLabel";
			this.typeLabel.Size = new System.Drawing.Size(147, 13);
			this.typeLabel.TabIndex = 2;
			this.typeLabel.Text = "Enter words typed per minute:";
			// 
			// wordType
			// 
			this.wordType.Location = new System.Drawing.Point(148, 41);
			this.wordType.Name = "wordType";
			this.wordType.Size = new System.Drawing.Size(60, 20);
			this.wordType.TabIndex = 3;
			// 
			// typeForm
			// 
			this.AcceptButton = this.typeBtn;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(214, 149);
			this.Controls.Add(this.wordType);
			this.Controls.Add(this.typeLabel);
			this.Controls.Add(this.typeBtn);
			this.Name = "typeForm";
			this.Text = "Typing Grade";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button typeBtn;
		private System.Windows.Forms.Label typeLabel;
		private System.Windows.Forms.TextBox wordType;
	}
}

